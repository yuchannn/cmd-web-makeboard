const express = require('express');
var fs = require('fs');
var template = require('./lib/template.js');
var path = require('path');
var sanitizeHtml = require('sanitize-html');
var qs = require('querystring');
var bodyParser = require('body-parser');
const { userInfo } = require('os');

const app = express()
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

app.get('/', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var title = 'Welcome';
    var description = 'Hello, Node.js';
    var list = template.list(filelist);
    var html = template.HTML(title, list,
      `<h2>${title}</h2>${description}`,
      ` <form action="/create">
          <button>create</button>
        </form>`,
      ` <form action="/study", method="get">
          <button class="menubtn">Study</button>
        </form>`,
      ` <form action="/Project1", method="get">
          <button class="menubtn">Project1</button>
        </form>`,
      ` <form action="/Project2", method="get">
          <button class="menubtn">Project2</button>
        </form>`,
      ` <form action="/Project3", method="get">
          <button class="menubtn">Project3</button>
        </form>`,
    );
    response.send(html);
  });
})
app.get('/study', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var title = 'Welcome';
    var description = 'Hello, Node.js';
    var list = template.list(filelist);
    var html = template.HTML(title, list,
      `<h2>${title}</h2>${description}`,
      ` <form action="/create">
          <button>create</button>
        </form>`,
      ` <form action="/study", method="get">
          <button class="menubtn">Study</button>
        </form>`,
      ` <form action="/Project1", method="get">
          <button class="menubtn">Project1</button>
        </form>`,
      ` <form action="/Project2", method="get">
          <button class="menubtn">Project2</button>
        </form>`,
      ` <form action="/Project3", method="get">
          <button class="menubtn">Project3</button>
        </form>`,
    );
    response.send(html);
  });
}) 
app.get('/Project1', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var title = 'Welcome';
    var description = 'Hello, Node.js';
    var list = template.list(filelist);
    var html = template.HTML(title, list,
      `<h2>${title}</h2>${description}`,
      ` <form action="/create">
          <button>create</button>
        </form>`,
      ` <form action="/study", method="get">
          <button class="menubtn">Study</button>
        </form>`,
      ` <form action="/Project1", method="get">
          <button class="menubtn">Project1</button>
        </form>`,
      ` <form action="/Project2", method="get">
          <button class="menubtn">Project2</button>
        </form>`,
      ` <form action="/Project3", method="get">
          <button class="menubtn">Project3</button>
        </form>`,
    );
    response.send(html);
  });
}) 
app.get('/Project2', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var title = 'Welcome';
    var description = 'Hello, Node.js';
    var list = template.list(filelist);
    var html = template.HTML(title, list,
      `<h2>${title}</h2>${description}`,
      ` <form action="/create">
          <button>create</button>
        </form>`,
      ` <form action="/study", method="get">
          <button class="menubtn">Study</button>
        </form>`,
      ` <form action="/Project1", method="get">
          <button class="menubtn">Project1</button>
        </form>`,
      ` <form action="/Project2", method="get">
          <button class="menubtn">Project2</button>
        </form>`,
      ` <form action="/Project3", method="get">
          <button class="menubtn">Project3</button>
        </form>`,
    );
    response.send(html);
  });
}) 
app.get('/Project3/', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var title = 'Welcome';
    var description = 'Hello, Node.js';
    var list = template.list(filelist);
    var html = template.HTML(title, list,
      `<h2>${title}</h2>${description}`,
      ` <form action="/create">
          <button>create</button>
        </form>`,
      ` <form action="/study", method="get">
          <button class="menubtn">Study</button>
        </form>`,
      ` <form action="/Project1", method="get">
          <button class="menubtn">Project1</button>
        </form>`,
      ` <form action="/Project2", method="get">
          <button class="menubtn">Project2</button>
        </form>`,
      ` <form action="/Project3", method="get">
          <button class="menubtn">Project3</button>
        </form>`,
    );
    response.send(html);
  });
}) 

app.get('/page/:pageID', function(request, response){
  fs.readdir('./data', function(error, filelist){
    var filteredId = path.parse(request.params.pageID).base;
    fs.readFile(`data/${filteredId}`, 'utf8', function(err, description){
      var title = request.params.pageID;
      var sanitizedTitle = sanitizeHtml(title);
      var sanitizedDescription = sanitizeHtml(description, {
        allowedTags:['h1']
      });
      var list = template.list(filelist);
      var html = template.HTML(sanitizedTitle, list,
        `<h2>${sanitizedTitle}</h2>${sanitizedDescription}`,
        ` <form action="/create">
            <button>create</button>
          </form>
          <form action="/update/${sanitizedTitle}">
            <button>update</button>
          </form>
          <form action="/">
            <button>Main page</button>
          </form>
          <form action="/delete_process" method="post">
            <input type="hidden" name="id" value="${sanitizedTitle}">
            <input type="submit" value="delete">
          </form>`,
        ` <form action="/study", method="get">
            <button class="menubtn">Study</button>
          </form>`,
        ` <form action="/Project1", method="get">
            <button class="menubtn">Project1</button>
          </form>`,
        ` <form action="/Project2", method="get">
            <button class="menubtn">Project2</button>
          </form>`,
        ` <form action="/Project3", method="get">
            <button class="menubtn">Project3</button>
          </form>`,
      );
      response.send(html);
    });
  });
})

app.get('/create',function(request,response){
  fs.readdir('./data', function(error, filelist){
    var title = 'WEB - create';
    var list = template.list(filelist);
    var html = template.HTML(title, list, `
      <style>
        #title{
          width:40rem;
          font-size:25px;
        }
        #description{
          width:40rem;
          height:30rem;
          font-size:18px;
        }
      </style>
      <form action="/update_process" method="post">
        <input type="hidden" name="id" value="title">
        <div><input type="text" id="title" name="title" placeholder="title" value="title"></div>
        <div>
          <textarea name="description" id="description" placeholder="description"></textarea>
        </div>
        <div>
          <input type="submit">
        </div>
      </form>
      `,``,
      ` <form action="/study", method="get">
            <button class="menubtn">Study</button>
          </form>`,
        ` <form action="/Project1", method="get">
            <button class="menubtn">Project1</button>
          </form>`,
        ` <form action="/Project2", method="get">
            <button class="menubtn">Project2</button>
          </form>`,
        ` <form action="/Project3", method="get">
            <button class="menubtn">Project3</button>
          </form>`);
    response.send(html);
  });
})
app.post('/create_process', function (request, response) {
  var post = request.body;
  var title = post.title;
  var description = post.description;
  fs.writeFile(`data/${title}`, description, 'utf8', function (err) {
    response.writeHead(302, { Location: `/?id=${title}` });
    response.end();
  })
});
app.get('/update/:pageID',function(request,response){
  fs.readdir('./data', function(error, filelist){
    var filteredId = path.parse(request.params.pageID).base;
    fs.readFile(`data/${filteredId}`, 'utf8', function(err, description){
      var title = request.params.pageID;
      var list = template.list(filelist);
      var html = template.HTML(title, list,
        `
        <style>
          #title{
            width:40rem;
            font-size:25px;
          }
          #description{
            width:40rem;
            height:30rem;
            font-size:15px;
          }
        </style>
        <form action="/update_process" method="post">
          <input type="hidden" name="id" value="${title}">
          <div><input type="text" id="title" name="title" placeholder="title" value="${title}"></div>
          <div>
            <textarea name="description" id="description" placeholder="description">${description}</textarea>
          </div>
          <div>
            <input type="submit">
          </div>
        </form>
        `,
        `<a href="/create">create</a> <a href="/update/${title}">update</a>`,
        ` <form action="/study", method="get">
            <button class="menubtn">Study</button>
          </form>`,
        ` <form action="/Project1", method="get">
            <button class="menubtn">Project1</button>
          </form>`,
        ` <form action="/Project2", method="get">
            <button class="menubtn">Project2</button>
          </form>`,
        ` <form action="/Project3", method="get">
            <button class="menubtn">Project3</button>
          </form>`,
      );
      response.send(html);
    });
  });
});
app.post('/update_process', function (request, response) {
  var post = request.body;
  var id = post.id;
  var title = post.title;
  var description = post.description;
  fs.rename(`data/${id}`, `data/${title}`, function (error) {
    fs.writeFile(`data/${title}`, description, 'utf8', function (err) {
      response.redirect('/?id=${title}');
    })
  });
});

app.post('/delete_process', function (request, response) {
  var post = request.body;
  var id = post.id;
  var filteredId = path.parse(id).base;
  fs.unlink(`data/${filteredId}`, function (error) {
    response.redirect('/');
  })
});
app.listen(3000, () => console.log('Example app listening on port 3000!'))
/*
var http = require('http');
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var template = require('./lib/template.js');
var path = require('path');
var sanitizeHtml = require('sanitize-html');

var app = http.createServer(function(request,response){
    var _url = request.url;
    var queryData = url.parse(_url, true).query;
    var pathname = url.parse(_url, true).pathname;
    if(pathname === '/'){
      if(queryData.id === undefined){
        
      } else {
        
      }
    } else if(pathname === '/create'){
      
    } else if(pathname === '/create_process'){
      
    } else if(pathname === '/update'){
      
    } else if(pathname === '/update_process'){
      
    } else if(pathname === '/delete_process'){
      
    } else {
      response.writeHead(404);
      response.end('Not found');
    }
});
app.listen(3000);
*/