console.log(1+1);
console.log(4-1);
console.log(2*2);
console.log(10/2);
